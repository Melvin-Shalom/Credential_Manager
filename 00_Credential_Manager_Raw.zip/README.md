<h1> TNP Minor Project 6th Sem </h1>

<p>
Crafting a Password Inspector, Password Generator, and Password Manager with Encryption using Java and Python. The Module used to encrypt the String is <b>Cryptography</b> module form python, and used <b>Flask</b> Framework for API to connect and use python's encryption function in java.
</p>

